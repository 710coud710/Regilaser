"""
Laser Presenter - Xử lý logic giao tiếp Laser Marking System
"""
from presenter.base_presenter import BasePresenter
from config import ConfigManager
from workers.laser_worker import LaserWorker


class LaserPresenter(BasePresenter):
    """Presenter xử lý Laser Marking communication (TCP)"""

    def __init__(self):
        super().__init__()

        config = ConfigManager().get()
        self.laser_ip = config.LASER_IP
        self.laser_port = config.LASER_PORT
        self.default_script = str(config.LASER_SCRIPT)
        self.command_timeout_ms = config.LASER_TIMEOUT_MS

        self.worker = LaserWorker(self.laser_ip, self.laser_port, self.command_timeout_ms)
        self.is_connected = False

    # ------------------------------------------------------------------
    # Connection
    # ------------------------------------------------------------------
    def connect(self, ip_address=None, port=None):
        """Kết nối đến Laser System"""
        target_ip = ip_address or self.laser_ip
        target_port = port or self.laser_port

        self.log_info(f"Connecting to Laser Controller: {target_ip}:{target_port}")
        try:
            self.worker.connect(target_ip, target_port)
            self.is_connected = True
            self.log_success("Laser controller connected successfully")
            return True
        except Exception as exc:
            self.is_connected = False
            self.log_error(f"Failed to connect to laser: {exc}")
            return False

    def disconnect(self):
        """Ngắt kết nối Laser System"""
        if not self.is_connected:
            return

        self.worker.disconnect()
        self.is_connected = False
        self.log_info("Disconnected from laser controller")

    # ------------------------------------------------------------------
    # GA / C2 / NT helpers
    # ------------------------------------------------------------------
    def activate_script(self, script_number=None):
        """Gửi lệnh GA để chọn script"""
        if not self._ensure_connection():
            return False

        script = str(script_number or self.default_script)
        self.log_info(f"Gửi GA command với script {script}")
        try:
            self.worker.send_ga(script, timeout_ms=self.command_timeout_ms)
            self.log_success("GA command thành công")
            return True
        except Exception as exc:
            self.log_error(f"GA command lỗi: {exc}")
            return False

    def set_content(self, script=None, block="2", content=""):
        """Gửi lệnh C2 để nạp dữ liệu vào block"""
        if not self._ensure_connection():
            return False

        script_id = str(script or self.default_script)
        self.log_info(f"Gửi C2 command (script={script_id}, block={block})")
        try:
            self.worker.send_c2(script_id, block, content, timeout_ms=self.command_timeout_ms)
            self.log_success("C2 command thành công")
            return True
        except Exception as exc:
            self.log_error(f"C2 command lỗi: {exc}")
            return False

    def start_marking(self):
        """Gửi lệnh NT để bắt đầu khắc"""
        if not self._ensure_connection():
            return False

        self.log_info("Gửi NT command (start marking)")
        try:
            self.worker.send_nt(timeout_ms=self.command_timeout_ms)
            self.log_success("NT command thành công")
            return True
        except Exception as exc:
            self.log_error(f"NT command lỗi: {exc}")
            return False

    # ------------------------------------------------------------------
    # High-level flows
    # ------------------------------------------------------------------
    def mark_psn(self, security_code, script=None):
        """
        Thực hiện laser marking với flow GA -> C2 -> NT

        Args:
            security_code (str): chuỗi Security Code cần nạp
            script (str|None): script override, None = lấy từ config
        """
        if not security_code:
            self.log_error("Security code không hợp lệ")
            return False

        script_id = script or self.default_script

        self.log_info("=== BAT DAU LASER MARKING ===")
        self.log_debug(f"Script={script_id}, SecurityCode={security_code}")

        if not self.activate_script(script_id):
            return False

        if not self.set_content(script_id, "2", security_code):
            return False

        if not self.start_marking():
            return False

        self.log_success("Laser marking hoàn tất")
        return True

    def send_custom_command(self, command, expect_keyword=None):
        """
        Gửi lệnh tùy ý (vd: menu 'Send PSN20 to LASER')

        Args:
            command (str): lệnh C2/GA/NT custom
            expect_keyword (str|None): response mong đợi
        """
        if not self._ensure_connection():
            return False

        self.log_info(f"Gửi custom command: {command.strip()}")
        try:
            response = self.worker.send_raw_command(
                command,
                expect_keyword=expect_keyword,
                timeout_ms=self.command_timeout_ms,
            )
            self.log_success(f"Laser response: {response or '(empty)'}")
            return True
        except Exception as exc:
            self.log_error(f"Custom command lỗi: {exc}")
            return False

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------
    def _ensure_connection(self):
        if self.is_connected:
            return True
        return self.connect(self.laser_ip, self.laser_port)

    def cleanup(self):
        """Dọn dẹp tài nguyên"""
        self.disconnect()
